import Movieform from './Movieform'
import Movieslist from './Movieslist'
import Search from './Search'

export {Movieform, Movieslist, Search} 